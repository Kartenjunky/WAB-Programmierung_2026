package com.camunda.academy;

public record OrderRequest(
        String product,
        Integer quantity
) {}
