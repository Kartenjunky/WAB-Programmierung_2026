package com.camunda.academy;

import io.camunda.client.CamundaClient;
import io.camunda.client.api.worker.JobWorker;
import io.camunda.client.impl.oauth.OAuthCredentialsProvider;
import io.camunda.client.impl.oauth.OAuthCredentialsProviderBuilder;

import java.net.URI;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class TicketApplication {
    private static String CAMUNDA_AUTHORIZATION_SERVER_URL = "https://login.cloud.camunda.io/oauth/token";
    private static String CAMUNDA_TOKEN_AUDIENCE = "zeebe.camunda.io";
    private static String CAMUNDA_REST_ADDRESS = "https://fra-1.zeebe.camunda.io/b42850e8-4b3a-43a5-b21c-eb215adaacad";
    private static String CAMUNDA_GRPC_ADDRESS = "https://b42850e8-4b3a-43a5-b21c-eb215adaacad.fra-1.zeebe.camunda.io:443";
    private static String CAMUNDA_CLIENT_ID = "p0uF.Hdvbb0n7tmqZlFT_2HsclvvNNlC";
    private static String CAMUNDA_CLIENT_SECRET = "ZEh.M2r6jc~WvwvX2GPSJzjOhucHg_pvZYqm~r9e5YvWH8qD2ShCsDgI.p4K6Fzj";
    public static void main(String[] args) {
        final OAuthCredentialsProvider credentialsProvider = new OAuthCredentialsProviderBuilder()
                .authorizationServerUrl(CAMUNDA_AUTHORIZATION_SERVER_URL)
                .audience(CAMUNDA_TOKEN_AUDIENCE)
                .clientId(CAMUNDA_CLIENT_ID)
                .clientSecret(CAMUNDA_CLIENT_SECRET)
                .build();

        try (final CamundaClient  client = CamundaClient.newClientBuilder()
                .grpcAddress(URI.create(CAMUNDA_GRPC_ADDRESS))
                .restAddress(URI.create(CAMUNDA_REST_ADDRESS))
                .credentialsProvider(credentialsProvider)
                .build()) {

            final Map<String, Object> variables = new HashMap<String, Object>();
            variables.put("customerID", 1);
            variables.put("product", "Ticket1");
            variables.put("quantity", 2);

            final JobWorker customerWorker =
                    client.newWorker()
                            .jobType("checkCustomer")
                            .handler(new CustomerCheckHandler())
                            .timeout(Duration.ofSeconds(10).toMillis())
                            .open();

            final JobWorker orderWorker =
                    client.newWorker()
                            .jobType("createOrder")
                            .handler(new CreateOrderHandler())
                            .timeout(Duration.ofSeconds(10).toMillis())
                            .open();

            client.newCreateInstanceCommand()
                    .bpmnProcessId("ticketProcess")
                    .latestVersion()
                    .variables(variables)
                    .send()
                    .join();

            Thread.sleep(70000);
            customerWorker.close();
            orderWorker.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
