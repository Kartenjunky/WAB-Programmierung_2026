package com.camunda.academy;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class CustomerService {

    private static final String BASE_URL = "https://brookless-highly-melody.ngrok-free.dev";

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public CustomerResponse checkCustomer(int customerId) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/customers/" + customerId))
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return objectMapper.readValue(response.body(), CustomerResponse.class);
        }

        if (response.statusCode() == 404) {
            return new CustomerResponse(
                    false,
                    customerId,
                    null,
                    null,
                    "Customer nicht vorhanden"
            );
        }

        throw new RuntimeException("Fehler bei /customers: HTTP " + response.statusCode() + " - " + response.body());
    }
}
