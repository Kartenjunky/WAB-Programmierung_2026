package com.camunda.academy;

public record CustomerResponse(
        Boolean valid,
        Integer id,
        String name,
        String email,
        String reason
) {}
