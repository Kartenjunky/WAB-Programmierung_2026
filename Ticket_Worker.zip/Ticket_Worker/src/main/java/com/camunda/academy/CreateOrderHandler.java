package com.camunda.academy;

import io.camunda.client.api.response.ActivatedJob;
import io.camunda.client.api.worker.JobClient;
import io.camunda.client.api.worker.JobHandler;

import java.util.HashMap;
import java.util.Map;

public class CreateOrderHandler implements JobHandler {
    private final OrderService orderService = new OrderService();

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception{

        final Map<String, Object> inputVariables = job.getVariablesAsMap();
        final Number quantityNumber = (Number) inputVariables.get("quantity");
        final String product =  (String) inputVariables.get("product");

        if (product == null || quantityNumber == null) {
            client.newFailCommand(job.getKey())
                    .retries(0)
                    .errorMessage("Variablen product und/oder quantity fehlen")
                    .send()
                    .join();
            return;
        }

        final int quantity = quantityNumber.intValue();

        try {
            final OrderResponse response = orderService.createOrder(product, quantity);

            final Map<String, Object> outputVariables = new HashMap<>();
            outputVariables.put("orderId", response.orderId());
            outputVariables.put("orderStatus", response.status());
            outputVariables.put("orderProduct", response.product());
            outputVariables.put("orderQuantity", response.quantity());
            outputVariables.put("ticketCreated", true);

            client.newCompleteCommand(job.getKey())
                    .variables(outputVariables)
                    .send()
                    .join();

        } catch (Exception e) {
            int remainingRetries = Math.max(job.getRetries() - 1, 0);

            client.newFailCommand(job.getKey())
                    .retries(remainingRetries)
                    .errorMessage("Ticketanlage fehlgeschlagen: " + e.getMessage())
                    .send()
                    .join();
        }
    }
}
