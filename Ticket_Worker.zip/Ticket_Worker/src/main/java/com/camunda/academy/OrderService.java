package com.camunda.academy;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class OrderService {

    private static final String BASE_URL = "https://brookless-highly-melody.ngrok-free.dev";

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public OrderResponse createOrder(String product, int quantity) throws Exception {
        OrderRequest orderRequest = new OrderRequest(product, quantity);
        String json = objectMapper.writeValueAsString(orderRequest);

    HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(BASE_URL + "/orders"))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(json))
            .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return objectMapper.readValue(response.body(), OrderResponse.class);
        }

        throw new RuntimeException("Fehler bei /orders: HTTP " + response.statusCode() + " - " + response.body());
    }
}
