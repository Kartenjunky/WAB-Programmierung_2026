package com.camunda.academy;

public record OrderResponse(
        Integer orderId,
        String status,
        String product,
        Integer quantity
) {}
