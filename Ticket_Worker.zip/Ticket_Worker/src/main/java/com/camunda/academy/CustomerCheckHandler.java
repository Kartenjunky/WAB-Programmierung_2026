package com.camunda.academy;

import io.camunda.client.api.response.ActivatedJob;
import io.camunda.client.api.worker.JobClient;
import io.camunda.client.api.worker.JobHandler;

import java.util.HashMap;
import java.util.Map;

public class CustomerCheckHandler implements JobHandler {
    private final CustomerService customerService = new CustomerService();

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception{

        final Map<String, Object> inputVariables = job.getVariablesAsMap();
        final Number customerIdNumber = (Number) inputVariables.get("customerID");

        if (customerIdNumber == null) {
            client.newFailCommand(job.getKey())
                    .retries(0)
                    .errorMessage("Variable customerID fehlt")
                    .send()
                    .join();
            return;
        }

        final int customerID = customerIdNumber.intValue();

        try {
            final CustomerResponse response = customerService.checkCustomer(customerID);

            final Map<String, Object> outputVariables = new HashMap<>();
            outputVariables.put("customerValid", response.valid());
            outputVariables.put("customerName", response.name());
            outputVariables.put("customerEmail", response.email());
            outputVariables.put("customerReason", response.reason());

            client.newCompleteCommand(job.getKey())
                    .variables(outputVariables)
                    .send()
                    .join();

        } catch (Exception e) {
            int remainingRetries = Math.max(job.getRetries() - 1, 0);

            client.newFailCommand(job.getKey())
                    .retries(remainingRetries)
                    .errorMessage("Kundenprüfung fehlgeschlagen: " + e.getMessage())
                    .send()
                    .join();
        }
    }
}
